package com.cg.veggie;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.veggie.dto.AdminDTO;
import com.cg.veggie.service.IAdminService;

@SpringBootTest
public class AdminServiceTest {
	public static final Logger LOGGER = LoggerFactory.getLogger(AdminServiceTest.class);
	@Autowired
	IAdminService service;

	@Test
	void testAddAdmin() {

		AdminDTO admin = new AdminDTO();

		admin.setEmailId("navaneeth@gamil.com");
		admin.setName("Navaneethan");
		admin.setPassword("navan123");
		admin.setPhoneNumber(987456);
		
AdminDTO adminResult =	service.addAdmin(admin);
		
		assertNotNull(adminResult);
		LOGGER.info("Valid add admin test case executed");

	}

}
