package com.cg.veggie;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.veggie.dto.VegetableDTO;
import com.cg.veggie.service.IVegetableService;

@SpringBootTest
public class VegetableServiceTest {

	public static final Logger LOGGER = LoggerFactory.getLogger(VegetableServiceTest.class);
	@Autowired
	IVegetableService service;

	@Test
	void testAddVegetable() {

		VegetableDTO vegetable = new VegetableDTO();

		vegetable.setVegetableName("Onion");
		vegetable.setVegetablePrice(50);

		VegetableDTO vegetableResult = service.addVegetable(vegetable);

		assertNotNull(vegetableResult);
		LOGGER.info("Valid add admin test case executed");
	}

}
