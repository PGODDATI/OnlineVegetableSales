package com.cg.veggie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineVegetableSeller1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
