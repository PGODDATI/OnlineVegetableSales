package com.cg.veggie;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.veggie.dto.CustomerDTO;
import com.cg.veggie.service.CustomerServiceImp;

@SpringBootTest
public class CustomerServiceTest {
	public static final Logger LOGGER = LoggerFactory.getLogger(CustomerServiceTest.class);
	@Autowired
	CustomerServiceImp service;

	@Test
	void testAddCustomer() {

		CustomerDTO customer = new CustomerDTO();

		customer.setEmailId("navanee@gmail.com");
		customer.setAddress("Trichy");
		customer.setCustomerName("Navaneethan");
		customer.setPassword("Navanee123");
		customer.setPhoneNumber(9876543210L);
		
CustomerDTO customerResult =	service.addCustomer(customer);
		
		assertNotNull(customerResult);
		LOGGER.info("Valid add Customer test case executed");

	}

	
}
