package com.cg.veggie.dto;

import org.springframework.stereotype.Component;

/**
*
*   @author  Keerthi
*   Last Modified Date : 06-06-2021
*   Description : Vegetable DTO for Online Vegetables Sales
*/

@Component
public class VegetableDTO {
	private long vegetableId;
	private double vegetablePrice;
	private String vegetableName;

	public long getVegetableId() {
		return vegetableId;
	}

	public void setVegetableId(long vegetableId) {
		this.vegetableId = vegetableId;
	}

	public double getVegetablePrice() {
		return vegetablePrice;
	}

	public void setVegetablePrice(double vegetablePrice) {
		this.vegetablePrice = vegetablePrice;
	}

	public String getVegetableName() {
		return vegetableName;
	}

	public void setVegetableName(String vegetableName) {
		this.vegetableName = vegetableName;
	}

}
