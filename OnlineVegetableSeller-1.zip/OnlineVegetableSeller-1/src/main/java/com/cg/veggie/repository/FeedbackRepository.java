package com.cg.veggie.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.veggie.entity.Feedback;

/**
*
*   @author Krishnaveni
*   Date : 07-06-2021
*   Description : Feedback Repository for Online Vegetables Sales
*/

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Integer> {

}
