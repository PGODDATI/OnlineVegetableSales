package com.cg.veggie.service;

import java.util.List;

import com.cg.veggie.dto.OrderDTO;
import com.cg.veggie.entity.Order;

public interface IOrderService {

	public OrderDTO addOrder(Order order);
	
	 public List<OrderDTO> getAllOrders();

}
