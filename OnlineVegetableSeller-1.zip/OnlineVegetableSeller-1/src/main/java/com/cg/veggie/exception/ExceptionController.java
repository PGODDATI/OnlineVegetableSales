package com.cg.veggie.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice 
public class ExceptionController {

	@ExceptionHandler({ InvalidCustomerDetailsException.class })
	public ResponseEntity<String> customerHandler() { 
		System.err.println("invalid");
		return new ResponseEntity<String>("Invalid Customer Details Inputs from GlobalExp Handler",
				HttpStatus.NOT_ACCEPTABLE);
	}
	
	@ExceptionHandler({ InvalidAdminDetailsException.class })
	public ResponseEntity<String> adminHandler() { 
		System.err.println("invalid");
		return new ResponseEntity<String>("Invalid Admin Details Inputs from GlobalExp Handler",
				HttpStatus.NOT_ACCEPTABLE);
	}
	
	@ExceptionHandler({ InvalidVegetableDetailsException.class })
	public ResponseEntity<String> vegetableHandler() { 
		System.err.println("invalid");
		return new ResponseEntity<String>("Invalid Vegetable Details Inputs from GlobalExp Handler",
				HttpStatus.NOT_ACCEPTABLE);
	}
	 
	   @ExceptionHandler({ InvalidFeedbackDetailsException.class }) public ResponseEntity<String> feedbackHandler() { 
			  System.err.println("invalid");
			  return new ResponseEntity<String>("Invalid feedback Details Inputs from GlobalExp Handler" ,HttpStatus.NOT_ACCEPTABLE); }

}
