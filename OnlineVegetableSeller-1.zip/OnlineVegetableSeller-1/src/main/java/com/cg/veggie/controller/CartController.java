package com.cg.veggie.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.veggie.dto.CartDTO;
import com.cg.veggie.entity.Cart;
import com.cg.veggie.service.ICartService;


/**
*
*   @author Esha
*   Date : 07-06-2021
*   Description : Cart Controller for Online Vegetables Sales
*/

@RestController
@RequestMapping("/api/veggie")
public class CartController {

	@Autowired
	ICartService service;
	Logger logger = LoggerFactory.getLogger(CartController.class);
	@PostMapping(value = "/add/cart")
	public CartDTO addCart(@RequestBody Cart cart) {
		logger.info(" vegetable added successfully. ");
		return service.addVegetable(cart);
	}

	@PutMapping(value = "/update/cart")
	public CartDTO updateCart(@RequestBody Cart cart) {
		logger.info(" cart updated successfully. ");
		return service.updateVegetable(cart);
	}

	@GetMapping("/get/cartlist")
	public List<CartDTO> getAllCart() {
		logger.info(" view cart list successful. ");
		return service.getAllVegetable();
	}

}
