package com.cg.veggie.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.veggie.entity.Cart;

/**
*
*   @author Esha
*   Date : 07-06-2021
*   Description : Cart Repository for Online Vegetables Sales
*/


@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {

}
