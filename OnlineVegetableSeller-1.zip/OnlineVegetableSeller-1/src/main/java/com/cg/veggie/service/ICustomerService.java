package com.cg.veggie.service;

import com.cg.veggie.dto.CustomerDTO;
import com.cg.veggie.entity.Customer;

public interface ICustomerService {

	public CustomerDTO addCustomer(CustomerDTO customer);

	public CustomerDTO updateCustomer(Customer customer);

}
