package com.cg.veggie.service;

import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.veggie.dto.AdminDTO;
import com.cg.veggie.entity.Admin;
import com.cg.veggie.repository.AdminRepository;
import com.cg.veggie.utils.AdminUtil;

/**
*
*   @author Praveen
*   Last Modified Date : 09-06-2021
*   Description : Admin Service Implementation for Online Vegetables Sales
*  
*   
*/

@Service
public class AdminServiceImp implements IAdminService {

	@Autowired
	AdminRepository repo;

	Logger logger = LoggerFactory.getLogger(IAdminService.class);

	@Override
	public AdminDTO addAdmin(AdminDTO admin) {
		Admin simpleAdmin=AdminUtil.convertToAdmin(admin);
		Admin admin1 = repo.save(simpleAdmin);
		AdminDTO adminDto = AdminUtil.convertToAdminDto(admin1);
		logger.info(" admin added successfully. ");
		return adminDto;
	}
	public static boolean validAdminDetails(AdminDTO admin) {
		boolean flag = false;

		if (Pattern.matches("^[A-Za-z]\\w{5,29}$", admin.getName())) {
			flag = true;
		}

		return flag;

	}

	@Override
	public AdminDTO updateAdmin(Admin admin) {
		Admin admin1 = repo.save(admin);
		AdminDTO adminDto = AdminUtil.convertToAdminDto(admin1);
		logger.info(" admin updated successfully. ");
		return adminDto;
	}

	@Override
	public List<AdminDTO> getAllAdmin() {
		List<Admin> list = repo.findAll();
		List<AdminDTO> adminDto = AdminUtil.convertToAdminDtoList(list);
		logger.info(" admin view list successful. ");
		return adminDto;
	}

}
