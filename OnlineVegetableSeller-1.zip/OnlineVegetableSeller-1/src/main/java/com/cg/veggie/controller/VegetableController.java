package com.cg.veggie.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.veggie.dto.VegetableDTO;
import com.cg.veggie.entity.Vegetable;
import com.cg.veggie.exception.InvalidVegetableDetailsException;
import com.cg.veggie.service.IVegetableService;
import com.cg.veggie.service.VegetableServiceImp;

/**
*
*   @author Keerthi
*   Last Modified Date : 09-06-2021
*   Description : Vegetable Controller for Online Vegetables Sales
*/

@RestController
@RequestMapping("api/veggie")
public class VegetableController {

	@Autowired
	IVegetableService service;
	Logger logger = LoggerFactory.getLogger(VegetableController.class);

	@PostMapping(value = "/add/vegetable")
	public VegetableDTO addVegetable(@RequestBody VegetableDTO vegetable) throws InvalidVegetableDetailsException{
		VegetableDTO vegetableDto = null;
		boolean isValid = VegetableServiceImp.validVegetableDetails(vegetable);
		if (isValid) {
			vegetableDto = service.addVegetable(vegetable);
		} else {
			throw new InvalidVegetableDetailsException();
		}
		logger.info(" vegetable added successfully. ");
		return vegetableDto;
	}

	@PutMapping("/update/vegetable")
	public VegetableDTO updateVegetable(@RequestBody Vegetable vegetable) {
		logger.info(" vegetable updated successfully. ");
		return service.updateVegetable(vegetable);

	}

	@GetMapping("/get/vegetablelist")
	public List<VegetableDTO> getAllVegetable() {
		List<VegetableDTO> vegetableDto = service.getAllVegetable();
		if (vegetableDto.isEmpty()) {
			logger.error("Empty list found");
		}
		logger.info(" Vegetable found");
		return vegetableDto;
	}

}
