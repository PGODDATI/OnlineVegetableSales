package com.cg.veggie.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "vegetable_info")
public class Vegetable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long vegetableId;
	@NotEmpty(message = "VegetablePrice should not be Empty")
	@Min(10)
	@Max(100)
	private double vegetablePrice;
	@NotEmpty(message = "VegetableName should not be Empty")
	private String vegetableName;

	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "vegetable")
	private Set<Order> order = new HashSet<>();
	@OneToOne(mappedBy="vegetable")
	private Customer customer;

	public long getVegetableId() {
		return vegetableId;
	}

	public void setVegetableId(long itemId) {
		this.vegetableId = itemId;
	}

	public double getVegetablePrice() {
		return vegetablePrice;
	}

	public void setVegetablePrice(double itemPrice) {
		this.vegetablePrice = itemPrice;
	}

	public String getVegetableName() {
		return vegetableName;
	}

	public void setVegetableName(String itemName) {
		this.vegetableName = itemName;
	}

}
