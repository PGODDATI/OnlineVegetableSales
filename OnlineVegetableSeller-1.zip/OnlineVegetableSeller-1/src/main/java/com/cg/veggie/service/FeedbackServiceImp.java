package com.cg.veggie.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.veggie.dto.FeedbackDTO;
import com.cg.veggie.entity.Feedback;
import com.cg.veggie.repository.FeedbackRepository;
import com.cg.veggie.utils.FeedbackUtil;

/**
*
*   @author Krishnaveni
*   Date : 07-06-2021
*   Description : Feedback Service Implementation for Online Vegetables Sales
*/

@Service
public class FeedbackServiceImp implements IFeedbackService {

	@Autowired
	FeedbackRepository repo;
	Logger logger = LoggerFactory.getLogger(IFeedbackService.class);

	@Override
	public FeedbackDTO addFeedback(FeedbackDTO feedback) {
		Feedback simpleFeedback=FeedbackUtil.convertToFeedback(feedback);
		Feedback feedback1 = repo.save(simpleFeedback);
		FeedbackDTO feedbackDto = FeedbackUtil.convertToFeedbackDto(feedback1);
		logger.info(" feedback added successfully. ");
		return feedbackDto;
	}
	public static boolean validFeedbackDetails(FeedbackDTO feedback) {
		boolean flag = false;

		if (feedback.getRatings()!=null) {
			flag = true;
		}

		return flag;

	}

	@Override
	public List<FeedbackDTO> getAllFeedback() {
		List<Feedback> list = repo.findAll();
		List<FeedbackDTO> feedbackDto = FeedbackUtil.convertToFeedbackDtoList(list);
		logger.info("  view feedback list successful. ");
		return feedbackDto;
	}

}
