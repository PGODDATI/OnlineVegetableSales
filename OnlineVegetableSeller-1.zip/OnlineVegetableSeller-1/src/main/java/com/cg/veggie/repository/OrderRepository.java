package com.cg.veggie.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.veggie.entity.Order;

/**
*
*   @author Navaneethan and Keerthi
*   Last Modified Date : 09-06-2021
*   Description : Order Repository for Online Vegetables Sales
*/

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {

}
