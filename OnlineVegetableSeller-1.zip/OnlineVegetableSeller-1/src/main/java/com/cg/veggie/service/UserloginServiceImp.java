/*package com.cg.veggie.service;

import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.veggie.dto.UserloginDTO;
import com.cg.veggie.entity.Userlogin;
import com.cg.veggie.repository.UserloginRepository;
import com.cg.veggie.utils.UserloginUtil;



@Service
public class UserloginServiceImp implements IUserloginService {

	@Autowired
	UserloginRepository repo;

	Logger logger = LoggerFactory.getLogger(IUserloginService.class);

	@Override
	public UserloginDTO addUserlogin(UserloginDTO userlogin) {
		Userlogin simpleUserlogin=UserloginUtil.convertToUserlogin(userlogin);
		Userlogin userlogin1 = repo.save(simpleUserlogin);
		UserloginDTO userloginDto = UserloginUtil.convertToUserloginDto(userlogin1);
		logger.info(" userlogin added successfully. ");
		return userloginDto;
	}

	public static boolean validUserloginDetails(UserloginDTO userlogin) {
		boolean flag = false;

		if (Pattern.matches("^[A-Za-z]\\w{5,29}$", userlogin.getUserloginName())) {
			flag = true;
		}

		return flag;

	}

	@Override
	public UserloginDTO updateUserlogin(Userlogin userlogin) {
		Userlogin userlogin1 = repo.save(userlogin);
		UserloginDTO userloginDto = UserloginUtil.convertToUserloginDto(userlogin1);
		logger.info(" userlogin updated successfully. ");
		return userloginDto;
	}

}*/