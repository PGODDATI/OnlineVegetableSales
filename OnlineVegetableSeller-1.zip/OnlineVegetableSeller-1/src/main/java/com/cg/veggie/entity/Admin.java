package com.cg.veggie.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "Admin_info")
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long adminId;
	@NotEmpty(message = "name should not be null")
	private String name;
	@NotEmpty(message = "password should not be null")
	private String password;
	@NotEmpty(message = "emailid should not be null")
	private String emailId;
	@NotEmpty(message = "phonenumber should not be null")
	private long phoneNumber;

	//@OneToMany(mappedBy = "admin", cascade = CascadeType.ALL)
	//private Set<Customer> customer = new HashSet<>();


	public long getAdminId() {
		return adminId;
	}

	public void setAdminId(long adminId) {
		this.adminId = adminId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
}
