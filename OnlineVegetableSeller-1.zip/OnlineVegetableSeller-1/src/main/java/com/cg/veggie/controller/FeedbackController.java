package com.cg.veggie.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.veggie.dto.FeedbackDTO;
import com.cg.veggie.exception.InvalidFeedbackDetailsException;
import com.cg.veggie.service.FeedbackServiceImp;
import com.cg.veggie.service.IFeedbackService;

/**
*
*   @author Krishnaveni
*   Date : 07-06-2021
*   Description : Feedback Controller for Online Vegetables Sales
*/

@RestController
@RequestMapping("api/veggie")
public class FeedbackController {

	@Autowired
	IFeedbackService service;
	Logger logger = LoggerFactory.getLogger(FeedbackController.class);
	@PostMapping("/add/feedback")
	public FeedbackDTO addFeedback(@RequestBody FeedbackDTO feedback)throws InvalidFeedbackDetailsException {
		FeedbackDTO feedbackDTO=null;
		boolean isValid=FeedbackServiceImp.validFeedbackDetails(feedback);
		if(isValid) {
			feedbackDTO=service.addFeedback(feedback);
		}
		else {
			throw new InvalidFeedbackDetailsException();
		}
		logger.info(" feedback added successfully. ");
		return feedbackDTO;
		
	}

	@GetMapping("/get/feedbacklist")
	public List<FeedbackDTO> getAllFeedback() {
		logger.info(" view all feedback successful. ");
		return service.getAllFeedback();
	}

}
