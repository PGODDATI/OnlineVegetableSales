package com.cg.veggie.service;

import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.veggie.dto.CustomerDTO;
import com.cg.veggie.entity.Customer;
import com.cg.veggie.repository.CustomerRepository;
import com.cg.veggie.utils.CustomerUtil;

/**
*
*   @author Navaneethan
*   Last Modified Date : 09-06-2021
*   Description : Customer Service Implementation for Online Vegetables Sales
*  
*   
*/

@Service
public class CustomerServiceImp implements ICustomerService {

	@Autowired
	CustomerRepository repo;

	Logger logger = LoggerFactory.getLogger(ICustomerService.class);

	@Override
	public CustomerDTO addCustomer(CustomerDTO customer) {
		Customer simpleCustomer=CustomerUtil.convertToCustomer(customer);
		Customer customer1 = repo.save(simpleCustomer);
		CustomerDTO customerDto = CustomerUtil.convertToCustomerDto(customer1);
		logger.info(" customer added successfully. ");
		return customerDto;
	}

	public static boolean validCustomerDetails(CustomerDTO customer) {
		boolean flag = false;

		if (Pattern.matches("^[A-Za-z]\\w{5,29}$", customer.getCustomerName())) {
			flag = true;
		}

		return flag;

	}

	@Override
	public CustomerDTO updateCustomer(Customer customer) {
		Customer customer1 = repo.save(customer);
		CustomerDTO customerDto = CustomerUtil.convertToCustomerDto(customer1);
		logger.info(" customer updated successfully. ");
		return customerDto;
	}

}
