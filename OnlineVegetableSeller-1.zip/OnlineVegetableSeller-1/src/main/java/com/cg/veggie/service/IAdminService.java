package com.cg.veggie.service;

import java.util.List;

import com.cg.veggie.dto.AdminDTO;
import com.cg.veggie.entity.Admin;

public interface IAdminService {

	public AdminDTO addAdmin(AdminDTO admin);

	public AdminDTO updateAdmin(Admin admin);

	public List<AdminDTO> getAllAdmin();

}
