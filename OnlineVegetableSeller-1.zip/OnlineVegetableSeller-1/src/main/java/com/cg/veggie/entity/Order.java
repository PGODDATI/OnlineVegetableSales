package com.cg.veggie.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "order_info")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long orderId;

	private String statusOfOrder;
	private double totalAmount;

	@ManyToOne
	@JoinColumn(name = "customerId")
	private Customer customer;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "customer_item", joinColumns = { @JoinColumn(name = "orderDetails") }, inverseJoinColumns = {
			@JoinColumn(name = "vegetableId") })

	private Set<Vegetable> vegetable = new HashSet<>();

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "paymentId")
	private Payment payment;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public String getStatusOfOrder() {
		return statusOfOrder;
	}

	public void setStatusOfOrder(String statusOfOrder) {
		this.statusOfOrder = statusOfOrder;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

}
