package com.cg.veggie.exception;

public class InvalidAdminDetailsException extends Exception{

	private static final long serialVersionUID = 1L;

}
