package com.cg.veggie.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.veggie.entity.Customer;

/**
*
*   @author Navaneethan
*   Last Modified Date : 09-06-2021
*   Description :Customer Repository for Online Vegetables Sales
*/

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
