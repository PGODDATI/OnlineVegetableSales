package com.cg.veggie.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.veggie.dto.OrderDTO;
import com.cg.veggie.entity.Order;
import com.cg.veggie.service.IOrderService;

/**
*
*   @author Keerthi
*   Date : 07-06-2021
*   Description : Order Controller for Online Vegetables Sales
*/

@RestController
@RequestMapping("/api/veggie")
public class OrderController {

	@Autowired
	IOrderService service;
	Logger logger = LoggerFactory.getLogger(OrderController.class);
	@PostMapping(value = "/add/order")
	public OrderDTO addOrder(@RequestBody Order order) {
		logger.info(" order added successfully. ");
		return service.addOrder(order);
	}
	
	@GetMapping("/get/orderlist")
	public List<OrderDTO> getAllOrders() {
		logger.info(" view all orders successful. ");
		return service.getAllOrders();
	}

}
