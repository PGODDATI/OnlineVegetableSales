package com.cg.veggie.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.veggie.dto.PaymentDTO;
import com.cg.veggie.entity.Payment;
import com.cg.veggie.service.IPaymentService;

/**
*
*   @author Navaneethan
*   Last Modified Date : 09-06-2021
*   Description : Payment Controller for Online Vegetables Sales
*/

@RestController
@RequestMapping("/api/veggie")
public class PaymentController {

	@Autowired
	IPaymentService service;

	Logger logger = LoggerFactory.getLogger(PaymentController.class);

	@PostMapping(value = "/add/payment")
	public PaymentDTO addPayment(@RequestBody Payment payment) {
		logger.info(" Payment added successfully. ");
		return service.addPayment(payment);

	}

	@PutMapping(value = "/update/payment")
	public PaymentDTO updatePayment(@RequestBody Payment payment) {
		logger.info(" payment updated successfully. ");
		return service.updatePayment(payment);
	}

}
