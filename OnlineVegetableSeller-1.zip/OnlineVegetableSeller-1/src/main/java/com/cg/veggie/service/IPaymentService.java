package com.cg.veggie.service;

import com.cg.veggie.dto.PaymentDTO;
import com.cg.veggie.entity.Payment;

public interface IPaymentService {

	public PaymentDTO addPayment(Payment payment);

	public PaymentDTO updatePayment(Payment payment);

}
