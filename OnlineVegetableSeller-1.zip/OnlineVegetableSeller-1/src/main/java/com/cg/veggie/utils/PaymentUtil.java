package com.cg.veggie.utils;

import java.util.ArrayList;
import java.util.List;

import com.cg.veggie.dto.PaymentDTO;

import com.cg.veggie.entity.Payment;

public class PaymentUtil {

	public static List<PaymentDTO> convertToPaymentDtoList(List<Payment> list) {
		List<PaymentDTO> dtolist = new ArrayList<PaymentDTO>();
		for (Payment payment : list)
			dtolist.add(convertToPaymentDto(payment));
		return dtolist;
	}

	public static Payment convertToItem(PaymentDTO paymentdto) {
		Payment payment = new Payment();
		payment.setAmount(paymentdto.getAmount());
		payment.setModeOfPayment(paymentdto.getModeOfPayment());

		return payment;
	}

	public static PaymentDTO convertToPaymentDto(Payment payment) {

		PaymentDTO paymentDto = new PaymentDTO();
		paymentDto.setAmount(payment.getAmount());
		paymentDto.setModeOfPayment(payment.getModeOfPayment());

		return paymentDto;
	}

}
