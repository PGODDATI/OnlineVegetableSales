package com.cg.veggie.utils;

import java.util.ArrayList;
import java.util.List;

import com.cg.veggie.dto.OrderDTO;
import com.cg.veggie.entity.Order;

public class OrderUtil {

	public static List<OrderDTO> convertToOrderDtoList(List<Order> list) {
		List<OrderDTO> dtolist = new ArrayList<OrderDTO>();
		for (Order order : list)
			dtolist.add(convertToOrderDTO(order));
		return dtolist;
	}

	public static Order convertToOrder(OrderDTO orderdto) {
		Order order = new Order();
		order.setOrderId(orderdto.getOrderId());

		order.setStatusOfOrder(orderdto.getStatusOfOrder());
		order.setTotalAmount(orderdto.getTotalAmount());

		return order;
	}

	public static OrderDTO convertToOrderDTO(Order order) {

		OrderDTO orderdto = new OrderDTO(); //
		orderdto.setOrderId(order.getOrderId());
		orderdto.setOrderId(order.getOrderId());

		orderdto.setStatusOfOrder(order.getStatusOfOrder());
		orderdto.setTotalAmount(order.getTotalAmount());

		return orderdto;
	}

}
