package com.cg.veggie.utils;

import java.util.ArrayList;
import java.util.List;

import com.cg.veggie.dto.VegetableDTO;
import com.cg.veggie.entity.Vegetable;

public class VegetableUtil {

	public static List<VegetableDTO> convertToVegetableDtoList(List<Vegetable> list) {
		List<VegetableDTO> dtolist = new ArrayList<VegetableDTO>();
		for (Vegetable vegetable : list)
			dtolist.add(convertToVegetableDto(vegetable));
		return dtolist;
	}

	public static Vegetable convertToVegetable(VegetableDTO vegetabledto) {
		Vegetable vegetable = new Vegetable();
		vegetable.setVegetableId(vegetabledto.getVegetableId());
		vegetable.setVegetableName(vegetabledto.getVegetableName());
		vegetable.setVegetablePrice(vegetabledto.getVegetablePrice());

		return vegetable;
	}

	public static VegetableDTO convertToVegetableDto(Vegetable vegetable) {

		VegetableDTO vegetabledto = new VegetableDTO();
		vegetabledto.setVegetableId(vegetable.getVegetableId());
		vegetabledto.setVegetablePrice(vegetable.getVegetablePrice());
		vegetabledto.setVegetableName(vegetable.getVegetableName());

		return vegetabledto;
	}

}
