package com.cg.veggie.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Customer_info")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long customerId;

	@NotEmpty
	@Size(min = 5, max = 30)
	private String customerName;

	@NotEmpty
	@Size
	@Size(min = 5, max = 30)
	private String password;

	@NotEmpty
	private String gender;

	@NotEmpty
	@Email
	private String emailId;

	@NotNull
	private long phoneNumber;
	private String address;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="vegetableId")
	private Vegetable vegetable;
	@ManyToOne
	@JoinColumn(name = "adminId")
	private Admin admin;

	@OneToMany(mappedBy = "customer",cascade=CascadeType.ALL)
	private Set<Order> order = new HashSet<>();

	@OneToOne
	private Cart cart;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "feedback")
	private Feedback feedback;

	@OneToOne
	@JoinColumn(name = "payment")
	private Payment payment;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Customer() {
		super();
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
