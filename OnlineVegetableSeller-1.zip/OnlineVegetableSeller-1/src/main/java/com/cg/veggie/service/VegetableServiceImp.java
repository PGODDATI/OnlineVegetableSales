package com.cg.veggie.service;

import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.veggie.dto.VegetableDTO;
import com.cg.veggie.entity.Vegetable;
import com.cg.veggie.repository.VegetableRepository;
import com.cg.veggie.utils.VegetableUtil;

/**
*
*   @author Keerthi
*   Last Modified Date : 09-06-2021
*   Description : Vegetable Service Implementation for Online Vegetables Sales
*  
*   
*/

@Service
public class VegetableServiceImp implements IVegetableService {

	@Autowired
	VegetableRepository repo;

	Logger logger = LoggerFactory.getLogger(IVegetableService.class);

	@Override
	public VegetableDTO addVegetable(VegetableDTO vegetable) {
		Vegetable simpleVegetable=VegetableUtil.convertToVegetable(vegetable);
		Vegetable vegetable1 = repo.save(simpleVegetable);
		logger.info(" Vegetable added successfully. ");
		return VegetableUtil.convertToVegetableDto(vegetable1);
	}
	public static boolean validVegetableDetails(VegetableDTO vegetable) {
		boolean flag= false;

		if (Pattern.matches("^[A-Za-z]\\w{2,29}$", vegetable.getVegetableName())) {
			flag = true;
		}
		return flag;
	}
	
	@Override
	public VegetableDTO updateVegetable(Vegetable vegetable) {
		Vegetable vegetable1 = repo.save(vegetable);
		logger.info(" Vegetable updated successfully. ");
		return VegetableUtil.convertToVegetableDto(vegetable1);
	}

	@Override
	public List<VegetableDTO> getAllVegetable() {
		List<Vegetable> vegetable1 = repo.findAll();
		logger.info(" Vegetable Details ");
		return VegetableUtil.convertToVegetableDtoList(vegetable1);

	}

	

}
