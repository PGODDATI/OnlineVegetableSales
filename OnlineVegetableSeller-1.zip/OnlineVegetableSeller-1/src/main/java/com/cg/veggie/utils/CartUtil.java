package com.cg.veggie.utils;

import java.util.ArrayList;
import java.util.List;

import com.cg.veggie.dto.CartDTO;
import com.cg.veggie.entity.Cart;

public class CartUtil {

	public static List<CartDTO> convertToCartDtoList(List<Cart> list) {
		List<CartDTO> dtolist = new ArrayList<CartDTO>();
		for (Cart cart : list)
			dtolist.add(convertToCartDto(cart));
		return dtolist;
	}

	public static Cart convertToCart(CartDTO cartdto) {
		Cart item = new Cart();
		item.setCartId(cartdto.getCartId()); 
		item.setQuantity(cartdto.getQuantity());
		return item;
	}

	public static CartDTO convertToCartDto(Cart cart) {

		CartDTO cartdto = new CartDTO();
		cartdto.setCartId(cart.getCartId());
		cartdto.setQuantity(cart.getQuantity());
		return cartdto;
	}

}
