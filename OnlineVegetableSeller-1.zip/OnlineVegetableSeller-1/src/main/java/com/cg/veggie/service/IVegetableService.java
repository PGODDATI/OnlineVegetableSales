package com.cg.veggie.service;

import java.util.List;

import com.cg.veggie.dto.VegetableDTO;
import com.cg.veggie.entity.Vegetable;

public interface IVegetableService {

	public abstract VegetableDTO addVegetable(VegetableDTO vegetable);

	public VegetableDTO updateVegetable(Vegetable vegetable);

	public List<VegetableDTO> getAllVegetable();

}
