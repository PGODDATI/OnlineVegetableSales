package com.cg.veggie.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.veggie.dto.CustomerDTO;
import com.cg.veggie.entity.Customer;
import com.cg.veggie.exception.InvalidCustomerDetailsException;
import com.cg.veggie.service.CustomerServiceImp;
import com.cg.veggie.service.ICustomerService;

/**
*
*   @author Navaneethan
*   Date : 07-06-2021
*   Description : Customer Controller for Online Vegetables Sales
*/

@RestController
@RequestMapping("/api/veggie")
public class CustomerController {

	@Autowired
	ICustomerService service;
	Logger logger = LoggerFactory.getLogger(CustomerController.class);

	@PostMapping(value = "/add/customer")
	public CustomerDTO addCustomer(@RequestBody CustomerDTO customer) throws InvalidCustomerDetailsException {

		CustomerDTO customerDto = null;
		boolean isValid = CustomerServiceImp.validCustomerDetails(customer);
		if (isValid) {
			customerDto = service.addCustomer(customer);
		} else {
			throw new InvalidCustomerDetailsException();
		}
		logger.info(" customer added successfully. ");
		return customerDto;

	}

	@PutMapping(value = "/update/customer")
	public CustomerDTO updateCustomer(@RequestBody Customer customer) {
		logger.info(" customer updated successfully. ");
		return service.updateCustomer(customer);
	}

}
