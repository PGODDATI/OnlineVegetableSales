package com.cg.veggie.exception;

public class InvalidCustomerDetailsException extends Exception {

	private static final long serialVersionUID = 1L;

}
