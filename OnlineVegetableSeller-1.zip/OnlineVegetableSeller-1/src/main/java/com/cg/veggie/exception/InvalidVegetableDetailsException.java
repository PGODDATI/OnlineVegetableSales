package com.cg.veggie.exception;

public class InvalidVegetableDetailsException extends Exception{

	
	private static final long serialVersionUID = 1L;

	
	
}
