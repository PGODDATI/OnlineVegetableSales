package com.cg.veggie.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.veggie.dto.OrderDTO;
import com.cg.veggie.entity.Order;
import com.cg.veggie.repository.OrderRepository;
import com.cg.veggie.utils.OrderUtil;

/**
*
*   @author Navaneethan and Keerthi
*   Last Modified Date : 09-06-2021
*   Description :Order Service Implementation for Online Vegetables Sales
*  
*   
*/

@Service
public class OrderServiceImp implements IOrderService {

	@Autowired
	OrderRepository repo;
	Logger logger = LoggerFactory.getLogger(IOrderService.class);
	@Override
	public OrderDTO addOrder(Order order) {
		Order order1 = repo.save(order);
		OrderDTO orderDto = OrderUtil.convertToOrderDTO(order1);
		logger.info(" Order added successfully. ");
		return orderDto;
	}
	@Override
	public List<OrderDTO> getAllOrders() {
		List<Order> list = repo.findAll();
		List<OrderDTO> orderDto = OrderUtil.convertToOrderDtoList(list);
		logger.info(" view order successful. ");
		return orderDto;
	}

}
