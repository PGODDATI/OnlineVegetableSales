package com.cg.veggie.service;

import java.util.List;

import com.cg.veggie.dto.FeedbackDTO;

public interface IFeedbackService {

	public FeedbackDTO addFeedback(FeedbackDTO feedback);

	public List<FeedbackDTO> getAllFeedback();

}
