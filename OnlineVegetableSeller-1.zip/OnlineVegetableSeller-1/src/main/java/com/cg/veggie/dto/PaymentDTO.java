package com.cg.veggie.dto;

import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
public class PaymentDTO {

	@Id
	private long paymentId;
	private int amount;
	private String modeOfPayment;

	public long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

}
