package com.cg.veggie.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.veggie.entity.Payment;

/**
*
*   @author Navaneethan
*   Date : 07-06-2021
*   Description : Payment Repository for Online Vegetables Sales
*/

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Integer> {

}
