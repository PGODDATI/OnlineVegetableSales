/*package com.cg.veggie.utils;

import java.util.ArrayList;
import java.util.List;

import com.cg.veggie.dto.UserloginDTO;
import com.cg.veggie.entity.Userlogin;

public class UserloginUtil {
	
	public static List<UserloginDTO> convertToUserloginDtoList(List<Userlogin> list) {
		List<UserloginDTO> dtolist = new ArrayList<UserloginDTO>();
		for (UserloginDTO userlogin : list)
			dtolist.add(convertToUserloginDto(userlogin));
		return dtolist;

}
	public static Userlogin convertToUserlogin(UserloginDTO userlogindto) {
		Userlogin userlogin = new Userlogin();
		userlogin.setName(userlogindto.getName());
		userlogin.setPassword(userlogindto.getPassword());
		userlogin.setEmailId(userlogindto.getEmailId());
		userlogin.setPhoneNumber(userlogindto.getPhoneNumber());
		return userlogin;
	}

	public static UserloginDTO convertToUserloginDto(Userlogin userlogin) {

		UserloginDTO userlogindto = new UserloginDTO();
		userlogindto.setName(userlogin.getName());
		userlogindto.setPassword(userlogin.getPassword());
		userlogindto.setEmailId(userlogin.getEmailId());
		userlogindto.setPhoneNumber(userlogin.getPhoneNumber());
		return userlogindto;
	}
}

*/