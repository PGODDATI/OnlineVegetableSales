package com.cg.veggie.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.veggie.dto.AdminDTO;
import com.cg.veggie.entity.Admin;
import com.cg.veggie.exception.InvalidAdminDetailsException;
import com.cg.veggie.service.AdminServiceImp;
import com.cg.veggie.service.IAdminService;


/**
*
*   @author Praveen
*   Date : 07-06-2021
*   Description : Admin Controller for Online Vegetables Sales
*/

@RestController
@RequestMapping("/api/veggie")
public class AdminController {

	@Autowired
	IAdminService service;
	Logger logger = LoggerFactory.getLogger(AdminController.class);
	@PostMapping("/add/admin")
	public AdminDTO addAdmin(@RequestBody AdminDTO admin) throws InvalidAdminDetailsException{
		AdminDTO adminDto = null;
		boolean isValid = AdminServiceImp.validAdminDetails(admin);
		if (isValid) {
			adminDto = service.addAdmin(admin);
		} else {
			throw new InvalidAdminDetailsException();
		}
		
		logger.info(" admin added successfully. ");
		return adminDto;
	}

	@PutMapping("/update/admin")
	public AdminDTO updateAdmin(@RequestBody Admin admin) {
		logger.info(" admin updated successfully. ");
		return service.updateAdmin(admin);
	}

	@GetMapping("/get/adminlist")
	public List<AdminDTO> getAllAdmin() {
		logger.info(" view admin list successful. ");
		return service.getAllAdmin();
	}

}
