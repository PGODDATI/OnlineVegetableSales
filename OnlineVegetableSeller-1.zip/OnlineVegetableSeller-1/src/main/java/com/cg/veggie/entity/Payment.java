package com.cg.veggie.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "payment_info")
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long paymentId;
	@NotEmpty
	private int amount;

	@NotEmpty
	private String modeOfPayment;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "orderId")
	@JsonIgnore
	private Order order;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "payment")
	@JsonIgnore
	private Customer customer;

	public long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public long getCustomerId() {
		return paymentId;
	}

	public void setCustomerId(long customerId) {
		this.paymentId = customerId;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", amount=" + amount + ", modeOfPayment=" + modeOfPayment
				+ ", order=" + order + ", customer=" + customer + "]";
	}

}
