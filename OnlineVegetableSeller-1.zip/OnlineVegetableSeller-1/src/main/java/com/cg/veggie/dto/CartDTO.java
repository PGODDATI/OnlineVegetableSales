package com.cg.veggie.dto;

import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
public class CartDTO {
	
	@Id
	private long cartId;
	private String quantity;
	public long getCartId() {
		return cartId;
	}

	public void setCartId(long cartId) {
		this.cartId = cartId;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

}
