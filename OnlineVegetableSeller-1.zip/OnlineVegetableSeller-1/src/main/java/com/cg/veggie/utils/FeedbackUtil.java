package com.cg.veggie.utils;

import java.util.ArrayList;
import java.util.List;

import com.cg.veggie.dto.FeedbackDTO;
import com.cg.veggie.entity.Feedback;

public class FeedbackUtil {

	public static List<FeedbackDTO> convertToFeedbackDtoList(List<Feedback> list) {
		List<FeedbackDTO> dtolist = new ArrayList<FeedbackDTO>();
		for (Feedback feedback : list)
			dtolist.add(convertToFeedbackDto(feedback));
		return dtolist;
	}

	public static Feedback convertToFeedback(FeedbackDTO feedbackdto) {
		Feedback feedback = new Feedback();
		feedback.setFeedbackId(feedbackdto.getFeedbackId());
		feedback.setRatings(feedbackdto.getRatings());
		feedback.setComments(feedbackdto.getComments());

		return feedback;
	}

	public static FeedbackDTO convertToFeedbackDto(Feedback feedback) {
		FeedbackDTO feedbackdto = new FeedbackDTO();
		feedbackdto.setFeedbackId(feedback.getFeedbackId());
		feedbackdto.setRatings(feedback.getRatings());
		feedbackdto.setComments(feedback.getComments());

		return feedbackdto;
	}

}
