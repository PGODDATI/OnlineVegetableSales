/*package com.cg.veggie.service;


import com.cg.veggie.dto.UserloginDTO;
import com.cg.veggie.entity.Userlogin;

public interface IUserloginService {

	public UserloginDTO addUserlogin(UserloginDTO userlogin);

	public UserloginDTO updateUserlogin(Userlogin userlogin);

}
*/