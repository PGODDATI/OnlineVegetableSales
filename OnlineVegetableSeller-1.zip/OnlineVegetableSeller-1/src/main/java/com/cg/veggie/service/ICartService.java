package com.cg.veggie.service;

import java.util.List;

import com.cg.veggie.dto.CartDTO;
import com.cg.veggie.entity.Cart;

public interface ICartService {

	public CartDTO addVegetable(Cart cart);

	public CartDTO updateVegetable(Cart cart);

	public List<CartDTO> getAllVegetable();

}
