package com.cg.veggie.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.veggie.entity.Vegetable;

/**
*
*   @author Keerthi
*   Date : 07-06-2021
*   Description : vegetable Repository for Online Vegetables Sales
*/

public interface VegetableRepository extends JpaRepository<Vegetable, Integer> {

}
