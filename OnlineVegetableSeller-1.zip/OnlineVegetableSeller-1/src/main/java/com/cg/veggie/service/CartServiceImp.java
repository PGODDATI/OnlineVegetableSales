package com.cg.veggie.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.veggie.dto.CartDTO;
import com.cg.veggie.entity.Cart;
import com.cg.veggie.repository.CartRepository;
import com.cg.veggie.utils.CartUtil;


/**
*
*   @author Esha
*   Date : 07-06-2021
*   Description : Cart Service Implementation for Online Vegetables Sales
*/


@Service
public class CartServiceImp implements ICartService {

	@Autowired
	CartRepository repo;

	Logger logger = LoggerFactory.getLogger(ICartService.class);

	@Override
	public CartDTO addVegetable(Cart cart) {
		Cart cart1 = repo.save(cart);
		CartDTO cartDto = CartUtil.convertToCartDto(cart1);
		logger.info(" Vegetable added successfully. ");
		return cartDto;
	}

	@Override
	public List<CartDTO> getAllVegetable() {
		List<Cart> list = repo.findAll();
		List<CartDTO> cartDto = CartUtil.convertToCartDtoList(list);
		logger.info(" view cart list successful. ");
		return cartDto;
	}

	@Override
	public CartDTO updateVegetable(Cart cart) {
		Cart cart1 = repo.save(cart);
		CartDTO cartDto = CartUtil.convertToCartDto(cart1);
		logger.info(" Vegetable updated successfully. ");
		return cartDto;
	}

}
