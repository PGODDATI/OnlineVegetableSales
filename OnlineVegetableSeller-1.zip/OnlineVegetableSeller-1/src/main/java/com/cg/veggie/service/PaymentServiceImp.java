package com.cg.veggie.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.veggie.dto.PaymentDTO;
import com.cg.veggie.entity.Payment;
import com.cg.veggie.repository.PaymentRepository;
import com.cg.veggie.utils.PaymentUtil;

/**
*
*   @author Navaneethan
*   Date : 07-06-2021
*   Description : Payment Service Implementation for Online Vegetables Sales
*/


@Service
public class PaymentServiceImp implements IPaymentService {

	@Autowired
	PaymentRepository repo;
	Logger logger = LoggerFactory.getLogger(IPaymentService.class);

	@Override
	public PaymentDTO addPayment(Payment payment) {
		Payment payment1 = repo.save(payment);
		PaymentDTO paymentDto = PaymentUtil.convertToPaymentDto(payment1);
		logger.info(" Payment added successfully. ");
		return paymentDto;
	}

	@Override
	public PaymentDTO updatePayment(Payment payment) {
		Payment payment1 = repo.save(payment);
		PaymentDTO paymentDto = PaymentUtil.convertToPaymentDto(payment1);
		logger.info(" payment updated successfully. ");
		return paymentDto;
	}

}
